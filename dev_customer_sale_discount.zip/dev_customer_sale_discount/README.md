Customer based Discount On Sale:
=========================================================
Customer based Discount On Sale
